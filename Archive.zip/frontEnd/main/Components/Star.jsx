import React from 'react';

const Star = () => {
    
    return (

        <ul class="ulReviews">
            <li className="star">
                <i className="far fa-star"></i>
                <i className="far fa-star"></i>
                <i className="far fa-star"></i>
                <i className="far fa-star"></i>
                <i className="far fa-star"></i>
                <span className="totalReviews">(275)</span>
            </li>
        </ul>
    )
}

export default Star;
